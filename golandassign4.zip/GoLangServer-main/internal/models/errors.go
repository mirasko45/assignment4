package models

import "errors"

var ErrNoRecord = errors.New("model: no matching record found")
